public class Rice
{
    private String name;
    private Boolean includeDrink;
    private String sideDish;


    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public Boolean getIncludeDrink() {
        return includeDrink;
    }

    public void setIncludeDrink(Boolean includeDrink) {
        this.includeDrink = includeDrink;
    }

    public String getsideDish() {
        return sideDish;
    }

    public void setsideDish(String sideDish) {
        this.sideDish = sideDish;
    }
}
